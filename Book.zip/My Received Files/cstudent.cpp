#include "cstudent.h"
#include<iostream>
#include<string>


using namespace std;
using namespace practice::student;
namespace alias = practice::student;

int cStudent::s_id;

cStudent:: cStudent()
{
	s_id++;
	m_id = s_id;
}

cStudent:: ~cStudent()
{
	cout<<"Out of this";
}

StudentRef alias::Student::create()
{
	StudentRef s1 = new cStudent ;
	return s1;
}

int cStudent::getId()
{
	return m_id;
}

std::string cStudent::getName()
{
	return m_name;
}

void cStudent::setName(std::string name)
{
	m_name = name;
}

void cStudent::setPhoneNumber(std::string number)
{
	m_number = number;
}

std::string cStudent::getPhoneNumber()
{
	return m_number;
}

StudyType cStudent::getType()
{
	return m_type;
}

void cStudent::setStudyType (StudyType type)
{
	m_type = type;
}





