#ifndef _CSTUDENT_H
#define _CSTUDENT_H

#include "/home/sai/WorkPractice_DONOTDELETE/include/student.h"
#include<iostream>
#include<string>

namespace practice
{
	namespace student
	{
		class Student;
		typedef Student* StudentRef;

		class StudentRepository;
		typedef StudentRepository* StudentRepositoryRef;

		class cStudent: public Student
		{
			static int s_id ;
			int m_id;
			std::string m_name,m_number;
			StudyType m_type;

			public:

			//	virtual ~cStudent(){};

			//	static StudentRef create() ;

			cStudent();

			~cStudent();

			virtual int getId() ;

			virtual std::string getName() ;

			virtual void setName(std::string name);

			virtual void setPhoneNumber(std::string number) ;

			virtual std::string getPhoneNumber();

			virtual StudyType getType() ;

			virtual void setStudyType (StudyType type) ;

		};
		//int cStudent::s_id
	}
}
#endif
