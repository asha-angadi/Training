#include<iostream>
#include"cstudentrepository.h"
#include<vector>
#include"cstudent.h"

using namespace std;
using namespace practice::student;
namespace alias = practice::student;

vector<StudentRef> myvec;
int flag1=0, flag2=0;

cStudentRepository::cStudentRepository()
{
	cout<<"Inside constructor";
}

cStudentRepository::~cStudentRepository()
{
	cout<<"out of cstudentrepository";
}

StudentRepositoryRef alias::StudentRepository::create()
{
	StudentRepositoryRef s2 = new cStudentRepository ;
	return s2;
}

void cStudentRepository::CreateNewStudent(StudentRef student) 
{
	cout<<"Create New Student"<<endl;
	myvec.push_back(student);	
	Display();
	cout<<endl;
}
	
void cStudentRepository::updateStudentInformation(StudentRef student)
{
	cout<<"Updating StudentInfo automatically from main";
	for(vector<StudentRef>::iterator it = myvec.begin(); it!=myvec.end();it++)
	{
		if ((*it)->getId()==student->getId())
	  {
		(*it)->setName(student->getName());
		(*it)->setPhoneNumber(student->getPhoneNumber());
		(*it)->setStudyType(student->getType());
		
	  }
	}
	cout<<" After updating"<<endl;
	Display();
	cout<<endl;
	
}
	
void cStudentRepository::getStudentById(int id)
{
	//cout<<"Get student by ID"<<endl;
	for(vector<StudentRef>::iterator it = myvec.begin(); it!=myvec.end();it++)
	{
		if ((*it)->getId()==id)
		{
			cout<<(*it)->getName()<<endl;
			cout<<(*it)->getPhoneNumber()<<endl;
			cout<<(*it)->getType()<<endl;
			flag1=1;
		}
	}
	if(flag1==0)
		  cout<<"Student not found"<<endl;
	cout<<endl;
}
	
void cStudentRepository::getStudentByName ( std::string name)
{
	//cout<<"Get student by name"<<endl;
	for(vector<StudentRef>::iterator it = myvec.begin(); it!=myvec.end();it++)
	{
		if((*it)->getName()==name)
		{
			cout<<(*it)->getName()<<endl;
			cout<<(*it)->getPhoneNumber()<<endl;
			cout<<(*it)->getType()<<endl;
			flag2=1;
		}
	}
	if (flag2==0)
		cout<<"Student not found"<<endl;
	
	cout<<endl;
}	

void cStudentRepository::Display()
{
	cout<< "Student details"<<endl;
	for(vector<StudentRef>::iterator it = myvec.begin(); it!=myvec.end();it++)
	{
		cout << "Name: " << (*it)->getName()<< endl;
		cout << "Phone number: " << (*it)->getPhoneNumber()<< endl;
		cout << "ID: " << (*it)-> getId() << endl;
		cout << "StudyType: " << (*it)->getType()<< endl;
	}

}
























