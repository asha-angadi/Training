#ifndef _STUDENTREPOSITORY_H
#define _STUDENTREPOSITORY_H
#include "/home/sai/WorkPractice_DONOTDELETE/include/student.h"

using namespace std;
namespace practice
{	
namespace student
{
	
class Student;
typedef Student* StudentRef;

class StudentRepository;
typedef StudentRepository* StudentRepositoryRef;
		
class cStudentRepository : public StudentRepository
{
	public:
	//virtual ~StudentRepository(){};
	
	//static StudentRepositoryRef create() ;
	
	cStudentRepository();
	
	~cStudentRepository();
	
	virtual void CreateNewStudent(StudentRef student) ;
	
	virtual void updateStudentInformation(StudentRef student);
	
	virtual void getStudentById(int id);
	
	virtual void getStudentByName ( std::string name) ;
	
	void Display();
	
};
}
}
#endif
