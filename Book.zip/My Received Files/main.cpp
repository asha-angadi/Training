#include<iostream>
#include "/home/sai/WorkPractice_DONOTDELETE/include/student.h"
using namespace std;
using namespace practice::student;

namespace alias = practice::student;

int main()
{
	string name;
	int id;
	alias::StudentRef st1,st2, st3;
	alias::StudentRepositoryRef strepref1, strepref2;
	
	st1=Student::create();	
	strepref1=StudentRepository::create();	
	st1->setName("sAi");
	st1->setPhoneNumber("9848032919");
	st1->setStudyType(StudyType_UnderGraduate);
	strepref1->CreateNewStudent(st1);
	
	st2=Student::create();	
	//strepref1=StudentRepository::create();	
	st2->setName("kumAr");
	st2->setPhoneNumber("9900251177");
	st2->setStudyType(StudyType_PostGraduate);
	strepref1->CreateNewStudent(st2);
	
	st3=Student::create();	
	//strepref1=StudentRepository::create();	
	st3->setName("gurrAm");
	st3->setPhoneNumber("9900251177");
	st3->setStudyType(StudyType_PostGraduate);
	strepref1->CreateNewStudent(st3);
	
	st2->setPhoneNumber("8861155411");
	strepref1->updateStudentInformation(st2);
	
	cout<<"Enter the ID to be searched"<<endl;
	cin>>id;
	strepref1->getStudentById(id);
	
	cout<<"Enter the name to be searched"<<endl;
	cin>>name;
	strepref1->getStudentByName(name);
	
	return 0;
}

	
	
	
	
