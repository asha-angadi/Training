#include<iostream>
using namespace std;

class Demo
{
	int *p;
public:
	Demo():p(new int(45))
	{
		cout<<"Demo::constr"<<endl;
	}
	~Demo()
	{
		cout<<"Demo::destr"<<endl;
		delete p;
	}
	void disp()
	{
		cout<<*p<<endl;
	}
};

class SmartPointer
{
     Demo *ptr;
public:
	SmartPointer(Demo *p):ptr(p)
	{
		cout<<"SmartPointer::constr"<<endl;
	}

	~SmartPointer()
	{
		cout<<"SmartPointer::destr"<<endl;
		delete ptr;
	}
	

	Demo* getPtr()
	{
		return ptr;
	}

};

void main()
{
	/*
	Demo *d;
	d = new Demo();
	d->disp();
	//delete d;
	*/
	SmartPointer s(new Demo());
	(s.getPtr())->disp();
}
