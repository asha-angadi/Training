
#include "Student.h"
Student::Student(int m , int a):marks(m),age(a)
{}

int Student::getMarks()
{
	return marks;
}
int Student::getAge()
{
	return age;
}
