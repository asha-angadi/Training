#include<iostream>
using namespace std;

class Student
{
	int marks;
	int age;
public:
	Student(int m , int a);
	int getMarks();
	int getAge();
};
