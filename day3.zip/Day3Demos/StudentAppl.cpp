
#include "Student.h"
void main()
{
	Student s(23,88);
	cout<<s.getMarks()<<" "<<s.getAge()<<endl;
}
