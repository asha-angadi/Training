(google_async_config = window.google_async_config || {})['ca-pub-1444228343479937'] = {"sra_enabled":false};
try{window.localStorage.setItem('google_sra_enabled', '0');}catch(e){}